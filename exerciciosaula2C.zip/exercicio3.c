#include <stdio.h>

int main(){
    double saldo, saque, transf, deposito, taxa,total;
    int consaldo, sair, op;
    char nome[50];

    saldo = 1000;  // saldo inicial

    while(1){ // while para deixar em loop at� que a op 5 seja escolhida
    printf("====MENU DE OPERACOES====\n"); // exibe o menu para escolha da op
    printf("1. Consultar saldo\n");
    printf("2. Realizar deposito\n");
    printf("3. Realizar saque\n");
    printf("4. Transferencia\n");
    printf("5. Sair do sistema\n");
    printf("Escolha uma opcao: ");
    scanf("%d", &op);
    switch (op){ // determina a op a ser exibida
        case 1:
        printf("====SALDO====\n");
        printf("Seu saldo atual: %.2lf\n", saldo); // exibe o saldo, com %.2lf formatando para exibir somente 2 casas apos a virgula
        break;
        case 2:
        printf("====DEPOSITO====\n");
        printf("Digite o valor para depositar(deposito min R$0.01): ");
        scanf("%lf", &deposito);
        if (deposito < 0.01){  
            printf("Valor invalido (m�nimo R$0.01)\n");
            break;
        }
        saldo = saldo + deposito; // atualiza o saldo
        printf("Deposito realizado com sucesso\n");
        break;
        case 3:
        printf("====SAQUE====\n");
        printf("Digite um valor para saque: ");
        scanf("%lf", &saque);
        if (saque > saldo){ // verifica se o valor do saque n�o � maior que o saldo existente
            printf("Saldo insuficiente!\n"); 
        } else if (saque <= 500){ // verifica se a op n�o ultrapassa o limite de 500
            printf("Operacao realizada com sucesso!\n");
            saldo = saldo - saque; // atualiza o valor do saldo existente
        } else {
        	printf("Limite excedido!\n");
		} break;
        case 4:
        printf("====TRANSFERENCIA====\n");
        printf("Digite o nome para quem deseja transferir: ");
        scanf("%s", nome);
        printf("Digite o valor a ser transferido: ");
        scanf("%lf", &transf);

        double taxa = transf * 0.01; // taxa de 1%
        double total = transf + taxa; // valor final a ser descontado do saldo

        if (total > saldo){ // verifica se o saldo � suficiente (incluindo taxa)
            printf("Saldo insuficiente!\n");
        } else if (transf <= 0){ 
            printf("Valor invalido!\n"); 
        } else {
            printf("Transferencia de R$%.2lf para %s realizada com sucesso!\n", transf, nome);
            printf("Taxa de R$%.2lf foi cobrada.\n", taxa);
            saldo = saldo - total; // desconta o valor + taxa
        } 
        break;
        case 5:
        printf("Encerrando sessao :)");
        return 0; 
    }

    }
}
