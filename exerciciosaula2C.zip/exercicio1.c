#include <stdio.h>

int main () {
	
	// Entrada
	int pont_inicial;
	int diferenca;
	printf("\nDigite sua pontuacao inicial: \n");
	scanf("%d", &pont_inicial);
	
	diferenca = pont_inicial; // Guarda a pontua��o inicial para calcular a diferen�a no final

	pont_inicial += 50;
	printf("\nPARABENS!! Voce ganhou uma fase \n");
	printf("Sua pontua��o: %d\n", pont_inicial);
	
	pont_inicial *= 2;
	printf("\nPARABENS!! Voce encontrou um item especial \n");
	printf("Sua pontuacao: %d\n", pont_inicial);
	
	pont_inicial -= 30;
	printf("\nVoce perdeu uma vida!\n");
	printf("Sua pontuacao %d\n", pont_inicial);

	pont_inicial += 15;
	printf("\nVoce ganhou um bonus de tempo\n");
	printf("Sua pontuacao %d\n", pont_inicial);

	pont_inicial /= 3;
	printf("\nVoce recebeu uma penalidade por dificuldade\n");
	printf("Sua pontuacao %d\n", pont_inicial);

	pont_inicial += 100;
	printf("\nVoce recebeu um bonus final!\n");
	printf("\n ==== Sua pontuacao final e de: %d ==== \n", pont_inicial);
	
// C�lculo da diferen�a entre pontua��o final e inicial
pont_inicial -= diferenca;

printf("A diferenca da sua pontuacao foi de: %d pontos", pont_inicial);
	return 0;
}

