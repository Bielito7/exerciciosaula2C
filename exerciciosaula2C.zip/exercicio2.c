#include <stdio.h>

int main() {
	
	float media, a, b, c;
    char conceito;
    int freq;

    printf("=== Sistema de Notas ===\n");

   
    printf("Digite a primeira nota: \n");
    scanf("%f", &a);
    printf("Digite a segunda nota: \n");
    scanf("%f", &b);
    printf("Digite a terceira nota: \n");
    scanf("%f", &c);
    
    printf("Digite sua frequencia em porcentagem (apenas o numero): \n");
    scanf("%d", &freq);
    
    media = (a + b + c ) / 3;
    
    if (media >= 9.0) {
    	conceito = 'A';
	} else if (media >= 7.0) {
		conceito = 'B';
	} else if (media >= 5.0) {
		conceito = 'C';
	} else {
		conceito = 'D';
	}
	printf("SEU CONCEITO: %c\n", conceito);
	
	if (media < 5 && freq < 75) {
		printf("Voc� est� reprovado por nota e falta... \n");	
	} else if (media < 5) {
		printf("Voc� esta reprovado por nota... \n");
    } else if (freq < 75) {
    	printf("Voce esta reprovado por frequencia... \n");
	} else {
		printf("VOCE ESTA APROVADO COM %.2f DE MEDIA E %d%% DE FREQUENCIA, PARABENS!! \n", media, freq);
	}
    return 0;
}
